//Sample functions for Jest to test, since it isn't working normally in the other files

function sum(a, b) {
    return a + b;
}

function difference(a,b) {
    return a - b;
}

module.exports = sum;
//module.exports = difference;